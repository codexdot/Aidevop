---
title: folio
emoji: 🐳
colorFrom: purple
colorTo: yellow
sdk: static
pinned: false
tags:
  - deepsite
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference